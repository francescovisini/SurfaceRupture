# Backbone Surface Rupture QGIS beta 0.6 - colleague test

## Where is the tool?
After installation, the plugin displays a welcome message. Open:

**Processing Toolbox > Backbone Surface Rupture > Build Backbone Surface Rupture**

You can also search for **Backbone Surface Rupture** in the Processing Toolbox.

## Test A - input already contains only principal faults
1. Load a polyline layer containing only the principal-fault surface ruptures for one or more events.
2. Choose the Event ID field.
3. Leave **Principal-fault classification field** blank.
4. Press Run using the default reconstruction parameters.

Expected behavior: all input features are used. No ranking/classification column is required.

## Test B - mixed input layer
1. Load a polyline layer containing principal and secondary/distributed ruptures.
2. Choose the Event ID field.
3. Choose the column that classifies rupture traces in **Principal-fault classification field**.
4. Enter the value identifying principal faults. Examples: `1`, `Principal`, or `Main`.
5. Press Run.

For SURE 2.0, use `Comp_rank` and value `1`.

## Please report
- QGIS version and operating system.
- Whether the welcome message made the tool easy to locate.
- Whether the principal-fault filtering options were clear.
- Any error message from the Processing log.
- Whether the four output layers were created correctly.
