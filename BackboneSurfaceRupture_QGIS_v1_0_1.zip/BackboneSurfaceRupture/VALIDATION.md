# MATLAB–QGIS equivalence checklist

Run these events first:

| Event | Main check |
|---|---|
| 19501214 | The central finite-length junction must be exported as one explicit artificial connection. |
| 19990920 | The BSR must reach the northern endpoint and preserve the final rank-1 piece. |
| 19151003 | Adaptive opposite-endpoint search must recover the complete rupture extent. |

Compare:

- ordered geometry;
- BSR length;
- global extent coverage;
- trace length and fraction;
- number of artificial connections;
- maximum and total connection length;
- cumulative distance and x/L.

Reference MATLAB values from the supplied output should be treated as the
acceptance target. Small metric discrepancies can arise from the event-specific
UTM projection used in QGIS versus the local equirectangular metric conversion
used by MATLAB; geometry and path topology should nevertheless agree.
