# Backbone Surface Rupture — QGIS 1.0

QGIS Processing implementation of the **Backbone Surface Rupture (BSR)** framework described in Visini (2026).

The tool reconstructs one continuous ordered backbone from mapped **principal-fault traces**. It is dataset-independent: SURE 2.0 Rank 1 traces are the reference application, but any polyline dataset can be used.

## Where to find the tool

After installation, open:

**Processing Toolbox > Backbone Surface Rupture > Build Backbone Surface Rupture**

The plugin also shows this location in its welcome and About dialogs.

## Input

The input must be a polyline layer. Two workflows are supported:

1. **The layer already contains only principal-fault traces.** Leave **Principal-fault classification field** blank; all features are used.
2. **The layer contains principal and secondary/distributed traces.** Select any attribute column identifying the principal traces and enter the corresponding value. Numeric and text values are accepted. Examples: `Comp_rank = 1`, `Class = Main`, or `Type = Principal`.

The event-ID field is user-selectable. If multiple event IDs are present, the tool processes them independently.

Secondary/distributed traces are not used by the current BSR algorithm and do not modify artificial-connection costs.

## Recommended defaults

- Maximum artificial connection distance: **15000 m**
- Off-trace travel-time multiplier: **5**
- Maximum allowed turn: **140 degrees**
- Tip-to-feature junction tolerance: **300 m**
- Maximum connections per significant exit: **50**
- Minimum global extent: **0.98**
- Adaptive endpoint levels per side: **10,20,30,50**

Internal defaults match the MATLAB reference implementation: immutable observed geometry, 1 m graph-node snapping, adaptive Douglas-Peucker tolerance of 50–500 m (0.002 of feature length), and 1 m final continuity tolerance.

## Outputs

### Backbone Surface Rupture
One BSR line per event. Important attributes include:

- `length_m`: total BSR length, including artificial connections;
- `network_cov`: fraction of the complete observed principal-fault network used by the BSR;
- `trace_frac`: fraction of BSR length lying on observed principal-fault traces;
- `n_gaps`, `max_gap_m`, `total_gap_m`;
- `extent_cov`: global extent coverage;
- `confidence`: A–D reconstruction confidence;
- `geom_flag`: `OK` or `LOW_TRACE_COVERAGE`.

### Artificial connections
Explicit GAP geometries with event ID, gap ID and length.

### Ordered BSR vertices and x/L
Ordered points containing:

- `distance_m`: cumulative BSR distance including GAPs;
- `x_over_l`: normalized distance along the complete BSR;
- `trace_dist_m`: trace-only cumulative distance;
- `x_l_trace`: normalized trace-only distance;
- edge type and source identifiers.

Artificial connections are automatically densified for output at a spacing comparable with the selected TRACE geometry. The sampling interval is the median TRACE vertex spacing, constrained to 10–100 m. Densification does **not** modify the BSR geometry, path selection, gap lengths or ranking.

### BSR event summary
Contains event-level principal-network coverage, BSR trace fraction, gap metrics, extent, turn/backtracking diagnostics, confidence and geometry flag.

## Confidence

Version 1.0 uses the same A–D classification as the MATLAB reference implementation. Confidence is assigned after BSR selection and does not influence path optimization.

## MATLAB equivalence

Version 1.0 is aligned with the final MATLAB reference implementation for:

- principal-fault input filtering, including arbitrary numeric/text classification fields or no filter;
- event-centred local equirectangular coordinates;
- recommended graph/path parameters;
- hierarchical candidate selection;
- BSR distance and x/L including artificial connections;
- densified GAP output vertices;
- reconstruction confidence and geometry flag terminology.

## Styling note

Automatic QGIS post-processing styles remain disabled because some QGIS builds reject Python post-processor objects and incorrectly report an otherwise successful Processing run as failed. This does not affect any geometry or metric.

Recommended display: principal traces light grey, BSR black, artificial connections red dashed.

## Citation and license

Reference: **Visini (2026)**.

The software is distributed under the MIT License. If the BSR methodology or software contributes to scientific work, please cite the associated publication.
