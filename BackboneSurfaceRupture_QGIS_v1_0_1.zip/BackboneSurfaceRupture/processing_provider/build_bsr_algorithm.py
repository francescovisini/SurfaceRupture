from __future__ import annotations

import math
from qgis.PyQt.QtCore import QCoreApplication, QVariant
from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsFeature,
    QgsFeatureSink,
    QgsField,
    QgsFields,
    QgsGeometry,
    QgsPointXY,
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingException,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterField,
    QgsProcessingParameterNumber,
    QgsProcessingParameterString,
    QgsProject,
    QgsWkbTypes,
)

from .bsr_core import (
    Part,
    assemble,
    build_graph,
    clean_part,
    confidence,
    evaluate,
    principal_axis,
    select_candidate,
    shortest_state_path,
)


class BuildBsrAlgorithm(QgsProcessingAlgorithm):
    INPUT = 'INPUT'
    EVENT_FIELD = 'EVENT_FIELD'
    RANK_FIELD = 'RANK_FIELD'
    RANK_VALUE = 'RANK_VALUE'
    EVENT_ID = 'EVENT_ID'
    MAX_GAP = 'MAX_GAP'
    OFF_MULT = 'OFF_MULT'
    MAX_TURN = 'MAX_TURN'
    JUNCTION_TOL = 'JUNCTION_TOL'
    MAX_CONNECTIONS = 'MAX_CONNECTIONS'
    MIN_COMPLETE = 'MIN_COMPLETE'
    EXTREME_LEVELS = 'EXTREME_LEVELS'
    OUTPUT_BSR = 'OUTPUT_BSR'
    OUTPUT_GAPS = 'OUTPUT_GAPS'
    OUTPUT_VERTICES = 'OUTPUT_VERTICES'
    OUTPUT_SUMMARY = 'OUTPUT_SUMMARY'
    APPLY_STYLE = 'APPLY_STYLE'

    def tr(self, text):
        return QCoreApplication.translate('BuildBsrAlgorithm', text)

    def name(self):
        return 'build_backbone_surface_rupture'

    def displayName(self):
        return self.tr('Build Backbone Surface Rupture')

    def group(self):
        return self.tr('Backbone Surface Rupture')

    def groupId(self):
        return 'backbone_surface_rupture'

    def createInstance(self):
        return BuildBsrAlgorithm()

    def shortHelpString(self):
        return self.tr(
            'Builds one ordered Backbone Surface Rupture from mapped principal-fault '
            'polylines. SURE rank-1 traces are one supported example, but the tool '
            'is not restricted to SURE datasets. If the input layer already contains '
            'only principal-fault traces, leave the classification field blank. '
            'For mixed datasets, select a field and value identifying the principal '
            'faults. The defaults reproduce the current reference settings. '
            'The tool also exports explicit artificial connections, ordered '
            'vertices with cumulative distance and x/L, and event-level metrics.\n\n'
            'Experimental beta: compare the output with the MATLAB reference '
            'before using it in production.'
        )

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.INPUT, self.tr('Input rupture layer'), [QgsProcessing.TypeVectorLine]))
        self.addParameter(QgsProcessingParameterField(
            self.EVENT_FIELD, self.tr('Event ID field'), parentLayerParameterName=self.INPUT,
            defaultValue='IdE'))
        self.addParameter(QgsProcessingParameterField(
            self.RANK_FIELD,
            self.tr('Principal-fault classification field (optional; blank = use all features)'),
            parentLayerParameterName=self.INPUT, optional=True, defaultValue=None))
        self.addParameter(QgsProcessingParameterString(
            self.RANK_VALUE,
            self.tr('Principal-fault value (ignored if classification field is blank)'),
            optional=True, defaultValue='1'))
        self.addParameter(QgsProcessingParameterString(
            self.EVENT_ID, self.tr('Event ID (blank = all events)'), optional=True,
            defaultValue=''))

        self.addParameter(QgsProcessingParameterNumber(
            self.MAX_GAP, self.tr('Maximum artificial connection distance (m)'),
            type=QgsProcessingParameterNumber.Double, defaultValue=15000.0,
            minValue=0.0))
        self.addParameter(QgsProcessingParameterNumber(
            self.OFF_MULT, self.tr('Off-trace travel-time multiplier'),
            type=QgsProcessingParameterNumber.Double, defaultValue=5.0, minValue=1.0))
        self.addParameter(QgsProcessingParameterNumber(
            self.MAX_TURN, self.tr('Maximum allowed turn (degrees)'),
            type=QgsProcessingParameterNumber.Double, defaultValue=140.0,
            minValue=0.0, maxValue=180.0))
        self.addParameter(QgsProcessingParameterNumber(
            self.JUNCTION_TOL, self.tr('Tip-to-feature junction tolerance (m)'),
            type=QgsProcessingParameterNumber.Double, defaultValue=300.0,
            minValue=0.0))
        self.addParameter(QgsProcessingParameterNumber(
            self.MAX_CONNECTIONS, self.tr('Maximum connections per significant exit'),
            type=QgsProcessingParameterNumber.Integer, defaultValue=50, minValue=1))
        self.addParameter(QgsProcessingParameterNumber(
            self.MIN_COMPLETE, self.tr('Minimum global extent for completion'),
            type=QgsProcessingParameterNumber.Double, defaultValue=0.98,
            minValue=0.0, maxValue=1.0))
        self.addParameter(QgsProcessingParameterString(
            self.EXTREME_LEVELS, self.tr('Adaptive endpoint levels per side'),
            defaultValue='10,20,30,50'))
        self.addParameter(QgsProcessingParameterBoolean(
            self.APPLY_STYLE, self.tr('Apply recommended layer styles'), defaultValue=True))

        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT_BSR, self.tr('Backbone Surface Rupture'), QgsProcessing.TypeVectorLine))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT_GAPS, self.tr('Artificial connections'), QgsProcessing.TypeVectorLine))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT_VERTICES, self.tr('Ordered BSR vertices and x/L'), QgsProcessing.TypeVectorPoint))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT_SUMMARY, self.tr('BSR event summary'), QgsProcessing.TypeVector))

    EARTH_RADIUS_M = 6371008.8

    @classmethod
    def _lonlat_to_local(cls, lon, lat, lon0, lat0):
        x = math.radians(lon - lon0) * cls.EARTH_RADIUS_M * math.cos(math.radians(lat0))
        y = math.radians(lat - lat0) * cls.EARTH_RADIUS_M
        return x, y

    @classmethod
    def _local_to_lonlat(cls, x, y, lon0, lat0):
        lon = lon0 + math.degrees(x / (cls.EARTH_RADIUS_M * math.cos(math.radians(lat0))))
        lat = lat0 + math.degrees(y / cls.EARTH_RADIUS_M)
        return lon, lat

    @staticmethod
    def _parts_from_geometry(geometry):
        if QgsWkbTypes.isMultiType(geometry.wkbType()):
            return geometry.asMultiPolyline()
        return [geometry.asPolyline()]

    @staticmethod
    def _parse_levels(text):
        levels = []
        for token in text.replace(';', ',').split(','):
            token = token.strip()
            if token:
                levels.append(max(1, int(token)))
        return levels or [10, 20, 30, 50]

    def processAlgorithm(self, parameters, context, feedback):
        source = self.parameterAsSource(parameters, self.INPUT, context)
        if source is None:
            raise QgsProcessingException(self.invalidSourceError(parameters, self.INPUT))

        event_field = self.parameterAsString(parameters, self.EVENT_FIELD, context)
        rank_field = self.parameterAsString(parameters, self.RANK_FIELD, context).strip()
        principal_value = self.parameterAsString(parameters, self.RANK_VALUE, context).strip()
        requested_event = self.parameterAsString(parameters, self.EVENT_ID, context).strip()
        apply_style = self.parameterAsBool(parameters, self.APPLY_STYLE, context)

        field_names = source.fields().names()
        if event_field not in field_names:
            raise QgsProcessingException(f'Event field not found: {event_field}')
        if rank_field and rank_field not in field_names:
            raise QgsProcessingException(
                f'Principal-fault classification field not found: {rank_field}')

        def matches_principal_value(raw_value):
            # Accept both numeric classifications (e.g. 1, 1.0) and text
            # classifications (e.g. Principal, Main).
            if not rank_field:
                return True
            if raw_value is None:
                return False
            raw_text = str(raw_value).strip()
            target_text = principal_value.strip()
            if raw_text.casefold() == target_text.casefold():
                return True
            try:
                return abs(float(raw_text) - float(target_text)) <= 1e-9
            except (TypeError, ValueError):
                return False

        selected = []
        event_values = set()
        for f in source.getFeatures():
            if rank_field and not matches_principal_value(f[rank_field]):
                continue
            event_text = str(f[event_field])
            if requested_event and event_text != requested_event:
                continue
            selected.append(f)
            event_values.add(event_text)

        if not selected:
            raise QgsProcessingException('No input features match the selected event/principal-fault filter.')

        if rank_field:
            feedback.pushInfo(
                f'Principal-fault filter: {rank_field} = {principal_value} | '
                f'{len(selected)} input features selected')
        else:
            feedback.pushInfo(
                f'Principal-fault filter: none | using all {len(selected)} input features')

        # The prototype supports all events in one run, creating one output feature per event.
        events = sorted(event_values)
        source_crs = source.sourceCrs()

        bsr_fields = QgsFields()
        for name, qtype in [('event_id', QVariant.String), ('length_m', QVariant.Double),
                            ('network_cov', QVariant.Double), ('trace_frac', QVariant.Double), ('n_gaps', QVariant.Int),
                            ('max_gap_m', QVariant.Double), ('total_gap_m', QVariant.Double),
                            ('extent_cov', QVariant.Double), ('confidence', QVariant.String),
                            ('geom_flag', QVariant.String)]:
            bsr_fields.append(QgsField(name, qtype))
        gap_fields = QgsFields()
        for name, qtype in [('event_id', QVariant.String), ('gap_id', QVariant.Int),
                            ('length_m', QVariant.Double)]:
            gap_fields.append(QgsField(name, qtype))
        vertex_fields = QgsFields()
        for name, qtype in [('event_id', QVariant.String), ('vertex_id', QVariant.Int),
                            ('distance_m', QVariant.Double), ('x_over_l', QVariant.Double),
                            ('trace_dist_m', QVariant.Double), ('x_l_trace', QVariant.Double),
                            ('edge_type', QVariant.String), ('edge_id', QVariant.Int),
                            ('source_id', QVariant.String)]:
            vertex_fields.append(QgsField(name, qtype))
        summary_fields = QgsFields()
        for name, qtype in [('event_id', QVariant.String), ('n_principal', QVariant.Int),
                            ('observed_m', QVariant.Double), ('bsr_m', QVariant.Double),
                            ('trace_m', QVariant.Double), ('gap_m', QVariant.Double),
                            ('network_cov', QVariant.Double), ('trace_frac', QVariant.Double),
                            ('n_gaps', QVariant.Int), ('max_gap_m', QVariant.Double),
                            ('mean_gap_m', QVariant.Double), ('total_gap_m', QVariant.Double),
                            ('extent_cov', QVariant.Double), ('reaches_end', QVariant.Int),
                            ('mean_turn', QVariant.Double), ('backtrack', QVariant.Double),
                            ('confidence', QVariant.String), ('geom_flag', QVariant.String)]:
            summary_fields.append(QgsField(name, qtype))

        bsr_sink, bsr_id = self.parameterAsSink(parameters, self.OUTPUT_BSR, context,
                                                bsr_fields, QgsWkbTypes.LineString, source_crs)
        gap_sink, gap_id = self.parameterAsSink(parameters, self.OUTPUT_GAPS, context,
                                                gap_fields, QgsWkbTypes.LineString, source_crs)
        vertex_sink, vertex_id = self.parameterAsSink(parameters, self.OUTPUT_VERTICES, context,
                                                      vertex_fields, QgsWkbTypes.Point, source_crs)
        summary_sink, summary_id = self.parameterAsSink(parameters, self.OUTPUT_SUMMARY, context,
                                                        summary_fields, QgsWkbTypes.NoGeometry, source_crs)

        cfg = {
            'junction_tolerance': self.parameterAsDouble(parameters, self.JUNCTION_TOL, context),
            'minimum_split_distance': 25.0,
            'split_merge_tolerance': 5.0,
            'duplicate_tolerance': 0.05,
            'minimum_feature_length': 1.0,
            'node_snap': 1.0,
            'dp_min': 50.0,
            'dp_max': 500.0,
            'dp_fraction': 0.002,
            'max_connections_per_exit': self.parameterAsInt(parameters, self.MAX_CONNECTIONS, context),
            'max_gap': self.parameterAsDouble(parameters, self.MAX_GAP, context),
            'min_gap': 2.0,
            'max_turn': self.parameterAsDouble(parameters, self.MAX_TURN, context),
            'off_multiplier': self.parameterAsDouble(parameters, self.OFF_MULT, context),
            'minimum_complete': self.parameterAsDouble(parameters, self.MIN_COMPLETE, context),
            'continuity_tolerance': 1.0,
            'endpoint_levels': self._parse_levels(
                self.parameterAsString(parameters, self.EXTREME_LEVELS, context)),
        }

        features_by_event = {e: [] for e in events}
        for f in selected:
            features_by_event[str(f[event_field])].append(f)

        for event_index, event_value in enumerate(events):
            if feedback.isCanceled():
                break
            feedback.pushInfo(f'Event {event_value}')
            event_features = features_by_event[event_value]

            # Match the MATLAB reference implementation exactly: first transform
            # all input vertices to WGS84, then use an event-centred local
            # equirectangular metric system with R = 6371008.8 m.
            geo_crs = QgsCoordinateReferenceSystem('EPSG:4326')
            to_geo = QgsCoordinateTransform(source_crs, geo_crs, QgsProject.instance())
            from_geo = QgsCoordinateTransform(geo_crs, source_crs, QgsProject.instance())

            geographic_parts = []
            all_lon = []
            all_lat = []
            for f in event_features:
                g = QgsGeometry(f.geometry())
                if source_crs != geo_crs:
                    g.transform(to_geo)
                for polyline in self._parts_from_geometry(g):
                    if len(polyline) < 2:
                        continue
                    ll = [(float(p.x()), float(p.y())) for p in polyline]
                    geographic_parts.append((f, ll))
                    all_lon.extend(p[0] for p in ll)
                    all_lat.extend(p[1] for p in ll)

            if not geographic_parts:
                feedback.reportError(f'Event {event_value}: no valid polyline geometry.', fatalError=False)
                continue

            lon0 = sum(all_lon) / len(all_lon)
            lat0 = sum(all_lat) / len(all_lat)

            def local_to_source(point):
                lon, lat = self._local_to_lonlat(point[0], point[1], lon0, lat0)
                q = QgsPointXY(lon, lat)
                return from_geo.transform(q) if source_crs != geo_crs else q

            parts = []
            part_counter = 0
            for f, ll in geographic_parts:
                xy = [self._lonlat_to_local(lon, lat, lon0, lat0) for lon, lat in ll]
                ids_value = f['IdS'] if 'IdS' in field_names else f.id()
                part = clean_part(Part(part_counter, f.id(), ids_value, xy),
                                  cfg['duplicate_tolerance'], cfg['minimum_feature_length'])
                if part is not None:
                    parts.append(part)
                    part_counter += 1

            if not parts:
                feedback.reportError(f'Event {event_value}: no valid principal-fault parts.', fatalError=False)
                continue

            total_observed = sum(p.length for p in parts)
            nodes, edges = build_graph(parts, cfg)
            _, _, progress, observed_extent = principal_axis(parts, nodes)
            tip_ids = [n.node_id for n in nodes if n.is_original_tip]
            tip_ids = sorted(set(tip_ids), key=lambda n: progress[n])

            candidates = []
            searched = set()
            for level in cfg['endpoint_levels']:
                nside = min(level, len(tip_ids) // 2)
                if nside < 1:
                    continue
                starts = tip_ids[:nside]
                ends = tip_ids[-nside:]
                level_count = 0
                for start in starts:
                    for end in ends:
                        key = tuple(sorted((start, end)))
                        if start == end or key in searched:
                            continue
                        searched.add(key)
                        cand = shortest_state_path(nodes, edges, start, end,
                                                   cfg['off_multiplier'], cfg['max_turn'])
                        if cand is None:
                            continue
                        cand.global_extent = min(1.0, abs(progress[end] - progress[start]) /
                                                 max(observed_extent, 1e-12))
                        cand.reaches_global = cand.global_extent >= cfg['minimum_complete']
                        evaluate(cand, nodes, edges, total_observed)
                        candidates.append(cand)
                        level_count += 1
                feedback.pushInfo(
                    f'  endpoint level {level}: {level_count} valid new paths; '
                    f'{len(searched)} pairs evaluated')
                if any(c.reaches_global for c in candidates):
                    break

            if not candidates:
                feedback.reportError(f'Event {event_value}: no valid BSR path found.', fatalError=False)
                continue

            best = select_candidate(candidates, cfg['minimum_complete'], 0.005)
            vertices, sequence, gaps, trace_len, gap_len, total_len = assemble(
                best, edges, cfg['continuity_tolerance'])
            trace_fraction = trace_len / total_len if total_len > 0 else 0.0
            final_max_gap = max((g[2] for g in gaps), default=0.0)
            conf, geom_flag = confidence(best.global_extent, best.trace_coverage, trace_fraction,
                                         final_max_gap, best.backtracking)

            # BSR line.
            source_points = []
            for v in vertices:
                q = local_to_source(v['point'])
                source_points.append(q)
            out = QgsFeature(bsr_fields)
            out.setGeometry(QgsGeometry.fromPolylineXY(source_points))
            out.setAttributes([event_value, total_len, best.trace_coverage, trace_fraction,
                               len(gaps), final_max_gap, gap_len,
                               best.global_extent, conf, geom_flag])
            bsr_sink.addFeature(out, QgsFeatureSink.FastInsert)

            # Explicit gaps.
            for gap_number, (_, geom, glen) in enumerate(gaps, 1):
                pts = [local_to_source(p) for p in geom]
                gf = QgsFeature(gap_fields)
                gf.setGeometry(QgsGeometry.fromPolylineXY(pts))
                gf.setAttributes([event_value, gap_number, glen])
                gap_sink.addFeature(gf, QgsFeatureSink.FastInsert)

            # Ordered vertices and x/L.
            for i, v in enumerate(vertices, 1):
                p = local_to_source(v['point'])
                vf = QgsFeature(vertex_fields)
                vf.setGeometry(QgsGeometry.fromPointXY(p))
                vf.setAttributes([event_value, i, v['cum_with'], v['x_over_l'],
                                  v['cum_trace'], v['x_over_l_trace_only'],
                                  v['edge_type'], v['edge_id'], str(v['ids_value'])])
                vertex_sink.addFeature(vf, QgsFeatureSink.FastInsert)

            sf = QgsFeature(summary_fields)
            max_gap = final_max_gap
            mean_gap = (gap_len / len(gaps)) if gaps else 0.0
            sf.setAttributes([event_value, len(parts), total_observed, total_len, trace_len,
                              gap_len, best.trace_coverage, trace_fraction, len(gaps),
                              max_gap, mean_gap, gap_len, best.global_extent,
                              int(best.reaches_global), best.mean_turn, best.backtracking,
                              conf, geom_flag])
            summary_sink.addFeature(sf, QgsFeatureSink.FastInsert)

            feedback.pushInfo(
                f'  BSR {total_len / 1000:.2f} km | extent {100 * best.global_extent:.1f}% | '
                f'trace fraction {100 * trace_fraction:.1f}% | gaps {len(gaps)} | confidence {conf}')
            feedback.setProgress(100.0 * (event_index + 1) / len(events))

        # QGIS automatically schedules Processing outputs for loading.
        # Automatic post-processing remains intentionally disabled in version 1.0
        # because some QGIS builds reject Python post-processor objects and
        # incorrectly mark an otherwise successful run as failed. This does
        # not affect any geometry or metric. Recommended styles are described
        # in the README and will return after cross-version testing.
        if apply_style:
            feedback.pushInfo(
                'Recommended styling requested. Output layers were created; '
                'automatic styling is currently disabled in version 1.0 for '
                'QGIS cross-version compatibility.')

        feedback.pushInfo('')
        feedback.pushInfo('Backbone Surface Rupture successfully reconstructed.')
        feedback.pushInfo('Outputs created:')
        feedback.pushInfo('  - Backbone Surface Rupture')
        feedback.pushInfo('  - Artificial connections')
        feedback.pushInfo('  - Ordered BSR vertices and x/L')
        feedback.pushInfo('  - BSR event summary')

        return {
            self.OUTPUT_BSR: bsr_id,
            self.OUTPUT_GAPS: gap_id,
            self.OUTPUT_VERTICES: vertex_id,
            self.OUTPUT_SUMMARY: summary_id,
        }

