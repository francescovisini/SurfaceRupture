from qgis.core import QgsProcessingProvider
from .build_bsr_algorithm import BuildBsrAlgorithm


class BsrProvider(QgsProcessingProvider):
    def loadAlgorithms(self, *args, **kwargs):
        self.addAlgorithm(BuildBsrAlgorithm())

    def id(self):
        return 'bsr'

    def name(self):
        return 'Backbone Surface Rupture'

    def longName(self):
        return self.name()
