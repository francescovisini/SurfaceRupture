"""Pure-Python numerical core for the experimental QGIS BSR tool.

The implementation follows the current MATLAB workflow closely, while keeping
all observed coordinates immutable. QGIS-specific I/O lives in the Processing
algorithm; this module only works with metric xy coordinate lists.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import heapq
import math
import numpy as np
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

Point = Tuple[float, float]


@dataclass
class Part:
    part_id: int
    source_fid: int
    ids_value: object
    xy: List[Point]
    cum: List[float] = field(default_factory=list)
    length: float = 0.0


@dataclass
class Node:
    node_id: int
    x: float
    y: float
    is_original_tip: bool = False
    is_significant_exit: bool = False


@dataclass
class Edge:
    edge_id: int
    n1: int
    n2: int
    edge_type: str
    length: float
    geom: List[Point]
    original_part: Optional[int] = None
    ids_value: object = None


@dataclass
class Candidate:
    start: int
    end: int
    directed_edges: List[Tuple[int, int]]
    path_cost: float
    global_extent: float = 0.0
    reaches_global: bool = False
    trace_coverage: float = 0.0
    n_trace: int = 0
    n_gap: int = 0
    max_gap: float = 0.0
    total_gap: float = 0.0
    mean_turn: float = 0.0
    backtracking: float = 0.0


def dist(a: Point, b: Point) -> float:
    return math.hypot(a[0] - b[0], a[1] - b[1])


def cumulative(xy: Sequence[Point]) -> List[float]:
    out = [0.0]
    for a, b in zip(xy[:-1], xy[1:]):
        out.append(out[-1] + dist(a, b))
    return out


def clean_part(part: Part, duplicate_tol: float, min_length: float) -> Optional[Part]:
    clean: List[Point] = []
    for p in part.xy:
        if not (math.isfinite(p[0]) and math.isfinite(p[1])):
            continue
        if not clean or dist(clean[-1], p) > duplicate_tol:
            clean.append(p)
    if len(clean) < 2:
        return None
    cum = cumulative(clean)
    if cum[-1] < min_length:
        return None
    part.xy = clean
    part.cum = cum
    part.length = cum[-1]
    return part


def point_segment_distance(p: Point, a: Point, b: Point) -> Tuple[float, float, Point]:
    vx, vy = b[0] - a[0], b[1] - a[1]
    den = vx * vx + vy * vy
    if den <= 0:
        return dist(p, a), 0.0, a
    t = ((p[0] - a[0]) * vx + (p[1] - a[1]) * vy) / den
    t = min(1.0, max(0.0, t))
    q = (a[0] + t * vx, a[1] + t * vy)
    return dist(p, q), t, q


def project_on_polyline(p: Point, part: Part) -> Tuple[float, float, Point]:
    best = (float('inf'), 0.0, part.xy[0])
    for i, (a, b) in enumerate(zip(part.xy[:-1], part.xy[1:])):
        d, t, q = point_segment_distance(p, a, b)
        if d < best[0]:
            along = part.cum[i] + t * dist(a, b)
            best = (d, along, q)
    return best


def merge_close(values: Iterable[float], tol: float) -> List[float]:
    vals = sorted(values)
    if not vals:
        return []
    out = [vals[0]]
    for v in vals[1:]:
        if v - out[-1] <= tol:
            out[-1] = 0.5 * (out[-1] + v)
        else:
            out.append(v)
    return out


def dp_indices(xy: Sequence[Point], tolerance: float) -> List[int]:
    n = len(xy)
    if n <= 2 or tolerance <= 0:
        return list(range(n))
    keep = {0, n - 1}
    stack = [(0, n - 1)]
    while stack:
        i1, i2 = stack.pop()
        if i2 <= i1 + 1:
            continue
        a, b = xy[i1], xy[i2]
        best_d, best_i = -1.0, None
        for i in range(i1 + 1, i2):
            d, _, _ = point_segment_distance(xy[i], a, b)
            if d > best_d:
                best_d, best_i = d, i
        if best_i is not None and best_d > tolerance:
            keep.add(best_i)
            stack.append((i1, best_i))
            stack.append((best_i, i2))
    return sorted(keep)


def point_at(part: Part, s: float) -> Point:
    if s <= 0:
        return part.xy[0]
    if s >= part.length:
        return part.xy[-1]
    lo = 0
    while lo + 1 < len(part.cum) and part.cum[lo + 1] < s:
        lo += 1
    ds = part.cum[lo + 1] - part.cum[lo]
    t = 0.0 if ds <= 0 else (s - part.cum[lo]) / ds
    a, b = part.xy[lo], part.xy[lo + 1]
    return (a[0] + t * (b[0] - a[0]), a[1] + t * (b[1] - a[1]))


def slice_part(part: Part, s1: float, s2: float) -> List[Point]:
    pts = [point_at(part, s1)]
    pts.extend(p for p, s in zip(part.xy, part.cum) if s1 < s < s2)
    pts.append(point_at(part, s2))
    out = [pts[0]]
    for p in pts[1:]:
        if dist(out[-1], p) > 1e-9:
            out.append(p)
    return out


def cluster_point(point: Point, nodes: List[Node], tol: float) -> int:
    for node in nodes:
        if math.hypot(node.x - point[0], node.y - point[1]) <= tol:
            return node.node_id
    nid = len(nodes)
    nodes.append(Node(nid, point[0], point[1]))
    return nid


def azimuth_start(geom: Sequence[Point]) -> float:
    if len(geom) < 2:
        return 0.0
    a, b = geom[0], geom[1]
    return math.degrees(math.atan2(b[0] - a[0], b[1] - a[1])) % 360.0


def azimuth_end(geom: Sequence[Point]) -> float:
    if len(geom) < 2:
        return 0.0
    a, b = geom[-2], geom[-1]
    return math.degrees(math.atan2(b[0] - a[0], b[1] - a[1])) % 360.0


def angular_difference(a: float, b: float) -> float:
    return abs((a - b + 180.0) % 360.0 - 180.0)


def principal_axis(parts: Sequence[Part], nodes: Sequence[Node]) -> Tuple[Point, Point, List[float], float]:
    """Return the global PCA axis using the same covariance/eigensystem steps as MATLAB.

    NumPy and MATLAB both call LAPACK for the symmetric eigensystem. Keeping the
    eigenvector sign returned by the solver (rather than forcing an x-positive
    axis) preserves the MATLAB start-to-end convention for x/L.
    """
    pts = np.asarray([p for part in parts for p in part.xy], dtype=float)
    centre = pts.mean(axis=0)
    centred = pts - centre
    covariance = (centred.T @ centred) / max(len(pts), 1)  # MATLAB cov(...,1)
    values, vectors = np.linalg.eigh(covariance)
    axis_arr = vectors[:, int(np.argmax(values))]
    norm = float(np.hypot(axis_arr[0], axis_arr[1])) or 1.0
    axis_arr = axis_arr / norm
    observed = centred @ axis_arr
    node_xy = np.asarray([(n.x, n.y) for n in nodes], dtype=float)
    node_progress_arr = (node_xy - centre) @ axis_arr
    axis = (float(axis_arr[0]), float(axis_arr[1]))
    return ((float(centre[0]), float(centre[1])), axis,
            node_progress_arr.astype(float).tolist(),
            float(observed.max() - observed.min()))


def build_graph(parts: Sequence[Part], cfg: Dict[str, float]):
    split: Dict[int, List[float]] = {p.part_id: [0.0, p.length] for p in parts}
    junction_records: List[Tuple[Point, int, float, Point]] = []

    for tip_part in parts:
        for tip in (tip_part.xy[0], tip_part.xy[-1]):
            for recv in parts:
                if recv.part_id == tip_part.part_id:
                    continue
                d, along, q = project_on_polyline(tip, recv)
                if d <= cfg['junction_tolerance'] and cfg['minimum_split_distance'] < along < recv.length - cfg['minimum_split_distance']:
                    split[recv.part_id].append(along)
                    junction_records.append((tip, recv.part_id, along, q))

    significant_points: List[Point] = []
    for p in parts:
        tol = max(cfg['dp_min'], min(cfg['dp_max'], cfg['dp_fraction'] * p.length))
        for i in dp_indices(p.xy, tol)[1:-1]:
            split[p.part_id].append(p.cum[i])
            significant_points.append(p.xy[i])
        split[p.part_id] = merge_close(split[p.part_id], cfg['split_merge_tolerance'])

    nodes: List[Node] = []
    edges: List[Edge] = []
    node_parts: Dict[int, set] = {}

    for p in parts:
        cuts = split[p.part_id]
        cuts[0], cuts[-1] = 0.0, p.length
        for s1, s2 in zip(cuts[:-1], cuts[1:]):
            if s2 - s1 <= cfg['split_merge_tolerance']:
                continue
            geom = slice_part(p, s1, s2)
            n1 = cluster_point(geom[0], nodes, cfg['node_snap'])
            n2 = cluster_point(geom[-1], nodes, cfg['node_snap'])
            eid = len(edges)
            edges.append(Edge(eid, n1, n2, 'TRACE', s2 - s1, geom, p.part_id, p.ids_value))
            node_parts.setdefault(n1, set()).add(p.part_id)
            node_parts.setdefault(n2, set()).add(p.part_id)

    original_tips: List[Tuple[Point, int]] = []
    for p in parts:
        original_tips.extend([(p.xy[0], p.part_id), (p.xy[-1], p.part_id)])
    for tip, _ in original_tips:
        for n in nodes:
            if math.hypot(n.x - tip[0], n.y - tip[1]) <= cfg['node_snap']:
                n.is_original_tip = True
                n.is_significant_exit = True
                break
    for sp in significant_points:
        nearest = min(nodes, key=lambda n: math.hypot(n.x - sp[0], n.y - sp[1]))
        if math.hypot(nearest.x - sp[0], nearest.y - sp[1]) <= 2.0 * cfg['node_snap']:
            nearest.is_significant_exit = True

    # Explicit junction connectors.
    existing_pairs = {tuple(sorted((e.n1, e.n2))) for e in edges}
    for tip, _, _, q in junction_records:
        tip_node = min(nodes, key=lambda n: math.hypot(n.x - tip[0], n.y - tip[1]))
        q_node = min(nodes, key=lambda n: math.hypot(n.x - q[0], n.y - q[1]))
        if tip_node.node_id == q_node.node_id:
            continue
        pair = tuple(sorted((tip_node.node_id, q_node.node_id)))
        if pair in existing_pairs:
            continue
        length = dist((tip_node.x, tip_node.y), (q_node.x, q_node.y))
        edges.append(Edge(len(edges), tip_node.node_id, q_node.node_id, 'JUNCTION', length,
                          [(tip_node.x, tip_node.y), (q_node.x, q_node.y)]))
        existing_pairs.add(pair)

    # Gap edges: significant exit -> nearest original tips on other parts.
    tip_nodes = [n for n in nodes if n.is_original_tip]
    for n in [n for n in nodes if n.is_significant_exit]:
        candidates = []
        for t in tip_nodes:
            if t.node_id == n.node_id:
                continue
            if node_parts.get(n.node_id, set()) & node_parts.get(t.node_id, set()):
                continue
            d = math.hypot(n.x - t.x, n.y - t.y)
            if cfg['min_gap'] <= d <= cfg['max_gap']:
                pair = tuple(sorted((n.node_id, t.node_id)))
                if pair not in existing_pairs:
                    candidates.append((d, t))
        candidates.sort(key=lambda x: x[0])
        for d, t in candidates[: int(cfg['max_connections_per_exit'])]:
            pair = tuple(sorted((n.node_id, t.node_id)))
            if pair in existing_pairs:
                continue
            edges.append(Edge(len(edges), n.node_id, t.node_id, 'GAP', d,
                              [(n.x, n.y), (t.x, t.y)]))
            existing_pairs.add(pair)

    return nodes, edges


def oriented(edge: Edge, direction: int):
    if direction == 1:
        return edge.geom, edge.n1, edge.n2
    return list(reversed(edge.geom)), edge.n2, edge.n1


def shortest_state_path(nodes: Sequence[Node], edges: Sequence[Edge], start: int, end: int,
                        off_multiplier: float, max_turn: float) -> Optional[Candidate]:
    outgoing: Dict[int, List[Tuple[int, int]]] = {}
    for e in edges:
        outgoing.setdefault(e.n1, []).append((e.edge_id, 1))
        outgoing.setdefault(e.n2, []).append((e.edge_id, -1))

    pq: List[Tuple[float, int, int]] = []
    best: Dict[Tuple[int, int], float] = {}
    parent: Dict[Tuple[int, int], Optional[Tuple[int, int]]] = {}

    for eid, direction in outgoing.get(start, []):
        e = edges[eid]
        if e.edge_type != 'TRACE':
            continue
        state = (eid, direction)
        cost = e.length
        best[state] = cost
        parent[state] = None
        heapq.heappush(pq, (cost, eid, direction))

    final_state = None
    while pq:
        cost, eid, direction = heapq.heappop(pq)
        state = (eid, direction)
        if cost != best.get(state):
            continue
        geom, _, at_node = oriented(edges[eid], direction)
        if at_node == end and edges[eid].edge_type == 'TRACE':
            final_state = state
            break
        end_az = azimuth_end(geom)
        for next_eid, next_dir in outgoing.get(at_node, []):
            if next_eid == eid:
                continue
            next_geom, _, _ = oriented(edges[next_eid], next_dir)
            if angular_difference(end_az, azimuth_start(next_geom)) > max_turn:
                continue
            mult = 1.0 if edges[next_eid].edge_type == 'TRACE' else off_multiplier
            new_cost = cost + edges[next_eid].length * mult
            next_state = (next_eid, next_dir)
            if new_cost < best.get(next_state, float('inf')):
                best[next_state] = new_cost
                parent[next_state] = state
                heapq.heappush(pq, (new_cost, next_eid, next_dir))

    if final_state is None:
        return None
    path = []
    s = final_state
    while s is not None:
        path.append(s)
        s = parent[s]
    path.reverse()
    if len({e for e, _ in path}) != len(path):
        return None
    return Candidate(start, end, path, best[final_state])


def evaluate(c: Candidate, nodes: Sequence[Node], edges: Sequence[Edge], total_observed: float):
    trace_len = 0.0
    gaps = []
    turns = []
    backward = 0.0
    gv = (nodes[c.end].x - nodes[c.start].x, nodes[c.end].y - nodes[c.start].y)
    gn = math.hypot(*gv) or 1.0
    gu = (gv[0] / gn, gv[1] / gn)
    prev_geom = None
    for eid, direction in c.directed_edges:
        e = edges[eid]
        geom, n1, n2 = oriented(e, direction)
        if e.edge_type == 'TRACE':
            trace_len += e.length
            v = (nodes[n2].x - nodes[n1].x, nodes[n2].y - nodes[n1].y)
            vn = math.hypot(*v) or 1.0
            if (v[0] / vn) * gu[0] + (v[1] / vn) * gu[1] < 0:
                backward += e.length
        elif e.edge_type in ('GAP', 'JUNCTION'):
            gaps.append(e.length)
        if prev_geom is not None:
            turns.append(angular_difference(azimuth_end(prev_geom), azimuth_start(geom)))
        prev_geom = geom
    c.trace_coverage = min(1.0, trace_len / max(total_observed, 1e-12))
    c.n_trace = sum(1 for eid, _ in c.directed_edges if edges[eid].edge_type == 'TRACE')
    c.n_gap = len(gaps)
    c.max_gap = max(gaps) if gaps else 0.0
    c.total_gap = sum(gaps)
    c.mean_turn = sum(turns) / len(turns) if turns else 0.0
    c.backtracking = backward / max(trace_len, 1e-12)
    return c


def select_candidate(candidates: Sequence[Candidate], min_complete: float, tol: float) -> Candidate:
    pool = list(candidates)
    complete = [c for c in pool if c.global_extent >= min_complete]
    if complete:
        pool = complete
    max_extent = max(c.global_extent for c in pool)
    pool = [c for c in pool if c.global_extent >= max_extent - tol]
    max_cov = max(c.trace_coverage for c in pool)
    pool = [c for c in pool if c.trace_coverage >= max_cov - 0.005]
    min_ngap = min(c.n_gap for c in pool)
    pool = [c for c in pool if c.n_gap == min_ngap]
    min_max = min(c.max_gap for c in pool)
    pool = [c for c in pool if c.max_gap <= min_max + 1.0]
    min_total = min(c.total_gap for c in pool)
    pool = [c for c in pool if c.total_gap <= min_total + 1.0]
    min_turn = min(c.mean_turn for c in pool)
    pool = [c for c in pool if c.mean_turn <= min_turn + 0.1]
    min_back = min(c.backtracking for c in pool)
    pool = [c for c in pool if c.backtracking <= min_back + 1e-4]
    return min(pool, key=lambda c: c.path_cost)


def _densify_polyline(geom: Sequence[Point], target_step: float) -> List[Point]:
    """Densify a polyline without changing its geometry.

    Points are sampled at approximately target_step along the original line.
    This is used only for exported GAP vertices/x/L and never affects path
    selection, ranking, gap lengths, or the reconstructed geometry.
    """
    pts = list(geom)
    if len(pts) < 2:
        return pts
    cum = cumulative(pts)
    total = cum[-1]
    if total <= 0 or target_step <= 0:
        return pts
    nseg = max(1, int(math.ceil(total / target_step)))
    if nseg <= 1:
        return pts
    queries = [total * i / nseg for i in range(nseg + 1)]
    out: List[Point] = []
    j = 0
    for q in queries:
        while j < len(cum) - 2 and cum[j + 1] < q:
            j += 1
        s0, s1 = cum[j], cum[j + 1]
        a, b = pts[j], pts[j + 1]
        if s1 <= s0:
            p = a
        else:
            t = (q - s0) / (s1 - s0)
            t = max(0.0, min(1.0, t))
            p = (a[0] + t * (b[0] - a[0]), a[1] + t * (b[1] - a[1]))
        if not out or dist(out[-1], p) > 1e-12:
            out.append(p)
    return out


def assemble(best: Candidate, edges: List[Edge], continuity_tol: float):
    sequence: List[Tuple[str, List[Point], Optional[int], object]] = []
    last = None
    for eid, direction in best.directed_edges:
        edge = edges[eid]
        geom, _, _ = oriented(edge, direction)
        etype = 'TRACE' if edge.edge_type == 'TRACE' else 'GAP'
        if last is not None and dist(last, geom[0]) > continuity_tol:
            sequence.append(('GAP', [last, geom[0]], None, None))
        if etype == 'GAP' and edge.length <= continuity_tol:
            last = geom[-1]
            continue
        sequence.append((etype, list(geom), edge.original_part, edge.ids_value))
        last = geom[-1]

    # Match the MATLAB reference output: derive an automatic GAP sampling
    # interval from the median positive vertex spacing of selected TRACE
    # geometry, bounded to 10--100 m. This affects exported vertices/x/L only.
    trace_steps: List[float] = []
    for etype, geom, _, _ in sequence:
        if etype != 'TRACE':
            continue
        trace_steps.extend(
            d for d in (dist(a, b) for a, b in zip(geom[:-1], geom[1:]))
            if math.isfinite(d) and d > 0
        )
    if trace_steps:
        gap_output_step = float(np.median(np.asarray(trace_steps, dtype=float)))
        gap_output_step = max(10.0, min(100.0, gap_output_step))
    else:
        gap_output_step = 100.0

    dense_sequence: List[Tuple[str, List[Point], Optional[int], object]] = []
    for etype, geom, part_id, ids_value in sequence:
        if etype == 'GAP':
            geom = _densify_polyline(geom, gap_output_step)
        dense_sequence.append((etype, geom, part_id, ids_value))
    sequence = dense_sequence

    vertices = []
    cum_with = 0.0
    cum_trace = 0.0
    previous = None
    trace_length = 0.0
    gap_length = 0.0
    gaps = []
    for seq_id, (etype, geom, part_id, ids_value) in enumerate(sequence, 1):
        for i, p in enumerate(geom):
            if previous is not None and not (i == 0 and dist(previous, p) <= 1e-9):
                step = dist(previous, p)
                cum_with += step
                if etype == 'TRACE':
                    cum_trace += step
                    trace_length += step
                else:
                    gap_length += step
            if not vertices or dist(vertices[-1]['point'], p) > 1e-9:
                vertices.append({'point': p, 'edge_type': etype, 'edge_id': seq_id,
                                 'part_id': part_id, 'ids_value': ids_value,
                                 'cum_with': cum_with, 'cum_trace': cum_trace})
            previous = p
        if etype == 'GAP':
            gl = sum(dist(a, b) for a, b in zip(geom[:-1], geom[1:]))
            gaps.append((seq_id, geom, gl))
    total = cum_with
    for v in vertices:
        v['x_over_l'] = v['cum_with'] / total if total > 0 else 0.0
        v['x_over_l_trace_only'] = v['cum_trace'] / trace_length if trace_length > 0 else 0.0
    return vertices, sequence, gaps, trace_length, gap_length, total


def confidence(global_extent: float, network_coverage: float, trace_fraction: float,
               max_gap: float, backtracking: float):
    """MATLAB-reference A--D confidence and geometry flag."""
    if global_extent < 0.90 or backtracking > 0.05:
        conf = 'D'
    elif max_gap > 10000 or global_extent < 0.95 or trace_fraction < 0.60:
        conf = 'C'
    elif max_gap > 5000 or trace_fraction < 0.80:
        conf = 'B'
    else:
        conf = 'A'
    geometry_flag = 'LOW_TRACE_COVERAGE' if network_coverage < 0.50 else 'OK'
    return conf, geometry_flag
