from qgis.PyQt.QtCore import QSettings, QTimer, Qt
from qgis.PyQt.QtWidgets import QAction, QMessageBox, QStyle
from qgis.core import QgsApplication

from .processing_provider.provider import BsrProvider


class BackboneSurfaceRupturePlugin:
    MENU_NAME = '&Backbone Surface Rupture'
    VERSION = '1.0.1'
    SETTINGS_WELCOME_KEY = 'BackboneSurfaceRupture/welcome_shown_1_0_1'

    def __init__(self, iface):
        self.iface = iface
        self.provider = None
        self.about_action = None
        self.getting_started_action = None

    def initGui(self):
        self.provider = BsrProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

        info_icon = self.iface.mainWindow().style().standardIcon(
            QStyle.SP_MessageBoxInformation)

        self.getting_started_action = QAction(
            info_icon, 'Getting Started', self.iface.mainWindow())
        self.getting_started_action.setObjectName(
            'BackboneSurfaceRuptureGettingStartedAction')
        self.getting_started_action.setToolTip(
            'Show Backbone Surface Rupture getting-started instructions')
        self.getting_started_action.triggered.connect(self.show_getting_started)

        self.about_action = QAction(
            info_icon, 'About Backbone Surface Rupture', self.iface.mainWindow())
        self.about_action.setObjectName('BackboneSurfaceRuptureAboutAction')
        self.about_action.setToolTip('About Backbone Surface Rupture')
        self.about_action.triggered.connect(self.show_about)

        self.iface.addPluginToMenu(self.MENU_NAME, self.getting_started_action)
        self.iface.addPluginToMenu(self.MENU_NAME, self.about_action)
        self.iface.addToolBarIcon(self.about_action)

        # Delay slightly so the main QGIS window is fully initialized.
        # The version-specific QSettings key makes the welcome screen appear
        # once after a new installation/update, but not at every QGIS launch.
        QTimer.singleShot(750, self.show_welcome_once)

    def _open_processing_toolbox(self):
        try:
            self.iface.showProcessingToolbox()
            return
        except Exception:
            pass

        # Fallback for QGIS builds where showProcessingToolbox is not exposed.
        try:
            action = self.iface.mainWindow().findChild(
                QAction, 'mActionShowProcessingToolbox')
            if action is not None:
                action.trigger()
        except Exception:
            pass

    def _getting_started_box(self, first_run=False):
        box = QMessageBox(self.iface.mainWindow())
        box.setWindowTitle(
            'Backbone Surface Rupture - Welcome' if first_run
            else 'Backbone Surface Rupture - Getting Started')
        box.setIcon(QMessageBox.Information)
        box.setTextFormat(Qt.RichText)

        heading = (
            '<h3>Backbone Surface Rupture installed</h3>' if first_run
            else '<h3>Getting started with Backbone Surface Rupture</h3>'
        )

        box.setText(
            heading
            + '<p><b>Where is the tool?</b></p>'
              '<p>Open the <b>Processing Toolbox</b> and go to:</p>'
              '<p style="margin-left:18px"><b>Backbone Surface Rupture '
              '&rarr; Build Backbone Surface Rupture</b></p>'
              '<p>You can also type <b>Backbone Surface Rupture</b> in the '
              'Processing Toolbox search box.</p>'
              '<hr>'
              '<p><b>Which input should I use?</b></p>'
              '<p>&bull; If your layer already contains only principal-fault '
              'traces, leave the <b>Principal-fault classification field</b> '
              'empty: all input features will be used.</p>'
              '<p>&bull; If principal and secondary/distributed ruptures are '
              'mixed in the same layer, select the attribute column that '
              'identifies the principal faults and enter its value.</p>'
              '<p>Examples: <b>Comp_rank = 1</b> for SURE 2.0, or '
              '<b>Class = Main</b> for a custom dataset.</p>'
              '<p><b>Reference:</b> Visini (2026) &nbsp; '
              '<b>License:</b> MIT</p>'
        )

        open_button = box.addButton(
            'Open Processing Toolbox', QMessageBox.ActionRole)
        box.addButton(QMessageBox.Ok)
        box.exec()

        if box.clickedButton() is open_button:
            self._open_processing_toolbox()

    def show_welcome_once(self):
        settings = QSettings()
        if settings.value(self.SETTINGS_WELCOME_KEY, False, type=bool):
            return

        self._getting_started_box(first_run=True)
        settings.setValue(self.SETTINGS_WELCOME_KEY, True)
        settings.sync()

    def show_getting_started(self):
        self._getting_started_box(first_run=False)

    def show_about(self):
        box = QMessageBox(self.iface.mainWindow())
        box.setWindowTitle('About Backbone Surface Rupture')
        box.setIcon(QMessageBox.Information)
        box.setTextFormat(Qt.RichText)
        box.setText(
            '<h3>Backbone Surface Rupture</h3>'
            f'<p>QGIS Processing tool, version {self.VERSION}</p>'
            '<p><b>Where to find it:</b><br>'
            'Processing Toolbox &rarr; Backbone Surface Rupture &rarr; '
            'Build Backbone Surface Rupture</p>'
            '<p><b>Reference:</b> Visini (2026)</p>'
            '<p><b>License:</b> MIT License</p>'
            '<p>Builds an ordered Backbone Surface Rupture from mapped '
            'principal-fault surface-rupture traces. SURE Rank 1 traces are '
            'one supported example, but the tool is not restricted to SURE data.</p>'
            '<p>If the input layer already contains only principal-fault traces, '
            'no classification field is required. For mixed datasets, select a '
            'classification field and specify the value identifying the principal '
            'faults (for example, <b>Comp_rank = 1</b> for SURE 2.0).</p>'
            '<p><b>Outputs:</b> Backbone Surface Rupture, artificial connections, '
            'ordered vertices with cumulative distance and x/L, and event summary.</p>'
            '<p>The default reconstruction parameters correspond to the recommended '
            'settings used in the reference implementation.</p>'
        )
        getting_started_button = box.addButton(
            'Getting Started', QMessageBox.ActionRole)
        open_button = box.addButton(
            'Open Processing Toolbox', QMessageBox.ActionRole)
        box.addButton(QMessageBox.Ok)
        box.exec()

        if box.clickedButton() is open_button:
            self._open_processing_toolbox()
        elif box.clickedButton() is getting_started_button:
            self.show_getting_started()

    def unload(self):
        if self.getting_started_action is not None:
            self.iface.removePluginMenu(
                self.MENU_NAME, self.getting_started_action)
            self.getting_started_action.deleteLater()
            self.getting_started_action = None

        if self.about_action is not None:
            self.iface.removePluginMenu(self.MENU_NAME, self.about_action)
            self.iface.removeToolBarIcon(self.about_action)
            self.about_action.deleteLater()
            self.about_action = None

        if self.provider is not None:
            QgsApplication.processingRegistry().removeProvider(self.provider)
            self.provider = None
