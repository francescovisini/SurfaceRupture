# Changelog

## 1.0.1
- Restored the one-time welcome/getting-started screen after installation or update.
- Added a persistent **Getting Started** command under Plugin > Backbone Surface Rupture.
- Added an **Open Processing Toolbox** button and a compatibility fallback for opening the toolbox.
- Clarified the optional principal-fault classification field with SURE (`Comp_rank = 1`) and generic (`Class = Main`) examples.
- No changes to the BSR reconstruction algorithm or numerical defaults.

## 1.0.0

- First non-beta release.
- Preserves the general v0.6 input workflow: optional user-selected principal-fault classification field with numeric or text values, or no filter for principal-only layers.
- Aligns reconstruction confidence exactly with the final MATLAB reference implementation.
- Adds the MATLAB-compatible geometry flag (`OK` / `LOW_TRACE_COVERAGE`).
- Densifies exported artificial-connection vertices using the median selected-TRACE vertex spacing, bounded to 10–100 m, so cumulative distance and x/L are sampled through gaps.
- Distinguishes `network_cov` (fraction of the observed principal-fault network used) from `trace_frac` (fraction of BSR length on observed principal traces).
- Adds trace-only cumulative distance and normalized trace-only distance to the ordered vertex output.
- Expands event-summary diagnostics while retaining the same reconstruction algorithm and recommended defaults.
- Updates About/welcome/version metadata to 1.0.0.
- Automatic style post-processing remains disabled for QGIS cross-version reliability.


## 0.5.0 beta

- Distance parameters are displayed explicitly in metres.
- Removed misleading degree units and validation warning icons from distance inputs.
- Added a clear successful-completion message and output list to the Processing log.
- Updated the About window with Visini (2026) and MIT License information.
- Added a short colleague-testing guide.
- Temporarily disabled automatic style post-processing to prevent a false Processing failure in QGIS builds that reject Python post-processor objects.
- No changes to the BSR reconstruction algorithm or recommended numerical defaults.

## 0.4.0 beta

- Attempted cross-version layer post-processing through Processing LayerDetails.


## 0.6.0 beta

- Added a one-time welcome dialog showing where the Processing algorithm is located.
- Added an **Open Processing Toolbox** button to the welcome and About dialogs.
- Generalized terminology from SURE/rank-1 to **principal-fault traces**.
- Made the principal-fault classification field optional.
- If no classification field is selected, all input features are used.
- If a classification field is selected, the user can choose any attribute column and specify either a numeric or text value identifying principal faults.
- SURE 2.0 remains supported through, for example, `Comp_rank = 1`.
- No reconstruction algorithm, default geometric parameter, path search, ranking rule, or output metric was changed.
