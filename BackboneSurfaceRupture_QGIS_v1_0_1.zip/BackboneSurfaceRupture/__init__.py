def classFactory(iface):
    from .plugin import BackboneSurfaceRupturePlugin
    return BackboneSurfaceRupturePlugin(iface)
